import"./src-CG1yvd_Q.js";import"./FilePreview-ClUnvwZs.js";import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./chunk-WYO6CB5R-KLF5iHg8.js";import"./chunk-ICXQ74PX-CP4KNjq0.js";import"./chunk-C7G6YPKG-C8x3Ophq.js";import"./chunk-OGEWGWER-CNtGJ-bE.js";import"./chunk-HOUHSVGY-Dm3Xa5bl.js";import"./chunk-Q4XR5HBZ-BrzcylJV.js";import"./chunk-ZGVPDNZ5-DyUgpK3z.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-52WLFC77-qZJ-SXhF.js";import"./chunk-32BRIVSS-BgysPR-i.js";import"./chunk-XXDRQBXY-Bjq2-PTQ.js";import"./chunk-VR4S4FIN-DHLN5pNA.js";import{r as t,t as n}from"./chunk-PUDLZKDR-DzRQ2FV_.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};